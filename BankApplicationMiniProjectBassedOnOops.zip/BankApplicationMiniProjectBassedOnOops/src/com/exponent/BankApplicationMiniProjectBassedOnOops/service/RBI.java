package com.exponent.BankApplicationMiniProjectBassedOnOops.service;

public interface RBI {

	public void creatAccount();

	public void showAccountDitails();

	public void showAccountBalance();

	public void depositMony();

	public void withdrowMony();

	public void upDateAccountDitails();

}
