package com.exponent.BankApplicationMiniProjectBassedOnOops.controller;

import com.exponent.BankApplicationMiniProjectBassedOnOops.service.RBI;
import com.exponent.BankApplicationMiniProjectBassedOnOops.serviceImpl.SBI;
import java.util.Scanner;



public class AdminController {
	public static void main(String[] args) {
		System.err.println("******** WELCOM TO SBI ********");
		
		Scanner sc = new Scanner(System.in);
		RBI rbi = new SBI();
		boolean flag = true;
		
		while (flag) {
			System.out.println("____________________________________");
			System.out.println("____________________________________");
			System.out.println("1 ! Creat Bank Account             ! ");
			System.out.println("2 ! Show Account Ditails           !");
			System.out.println("3 ! Show Account Balance           !");
			System.out.println("4 ! Deposit Mony                   !");
			System.out.println("5 ! Withdrow Mony                  !");
			System.out.println("6 ! UP-date Account Ditails        !");
			System.out.println("7 ! Exit                           !");
			
			System.out.println(" ENTER YOUR CHOICE BETWEEN 1 TO 7 ");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				rbi.creatAccount();
				break;
				
			case 2:
				rbi.showAccountDitails();
				break;
				
			case 3:
				rbi.showAccountBalance();
				break;
				
			case 4: 
				rbi.depositMony();
				break;
				
			case 5:
				rbi.withdrowMony();
				break;
				
			case 6:
				rbi.upDateAccountDitails();
				break;
				
			case 7:
				flag = false;
				break;
				
				default:
					System.out.println(" INVALID NUMBER PLEASE SELECT CORRECT NUMBER");
					break;
			}
		}
		
	}

}
