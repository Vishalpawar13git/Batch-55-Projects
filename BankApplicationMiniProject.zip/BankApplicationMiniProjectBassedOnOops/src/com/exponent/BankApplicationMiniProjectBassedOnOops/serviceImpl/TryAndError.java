package com.exponent.BankApplicationMiniProjectBassedOnOops.serviceImpl;

import java.util.regex.Pattern;

public class TryAndError {

	public static void main(String[] args, CharSequence number) {

//		   Scanner sc = new Scanner(System.in);
//		   System.out.println("Enter your Name :- ");
//			String name = sc.next();
//			char[] ch = name.toCharArray();
//			boolean flag = true;
//			for (int i = 0; i < ch.length; i++) {
//				if (!(name.charAt(i) >= 'a' && name.charAt(i) <= 'z')
//						&& !(name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')) {
//
//					flag = false;
//				}
//			}
//
//			if (!flag) {
//				System.out.println("Invalid I/p");
//				return validateAccountHolderName();
//			}
//
//			return name;
//			
		String Pancard = "NGHP2225F";
//
		
//		if (Pattern.matches("[0-9]{10}+", number)) {
//			System.out.println("VALID");
//		} else {
//			System.out.println("invalid input");
//		}

	}
}