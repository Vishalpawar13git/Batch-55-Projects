
package com.exponent.BankApplicationMiniProjectBassedOnOops.serviceImpl;

import java.util.Scanner;

import com.exponent.BankApplicationMiniProjectBassedOnOops.model.Account;
import com.exponent.BankApplicationMiniProjectBassedOnOops.service.RBI;
import com.exponent.BankApplicationMiniProjectBassedOnOops.Validations.*;

public class SBI implements RBI {

	Scanner sc = new Scanner(System.in);
	Account ac = new Account();
	long accNo;
	// private String validateHoldername;

	@Override
	public void creatAccount() {

		System.out.println("enter your account number");
		int acNo = sc.nextInt();
		ac.setAccountNo(acNo);

		// System.out.println("enter your name");
		ac.setAccountName(Validations.validateAccountHolderName());
		
		System.out.println("enter your aadhar card");
		ac.setAadharcard(sc.next());
		
		System.out.println("enter your pancard");
		ac.setPanCard(sc.next());
		
		System.out.println("enter your contact no");
		ac.setContact(sc.nextLong());
		
		System.out.println("enter your mail id");
		ac.setMail(sc.next());
		
		System.out.println("enter your account opening balance");
		ac.setAccountBalance(sc.nextDouble());
		
		System.out.println("account creation successfull");

	}

	@Override
	public void showAccountDitails() {
		System.out.println("Enter your acconut");
		int accNo = sc.nextInt();
		if (ac.getAccountNo() == accNo) {
			System.out.println(ac);
		} else {
			System.out.println("account does't exist");
		}

	}

	@Override
	public void showAccountBalance() {
		System.out.println("enter your account");
		int accNo = sc.nextInt();
		if (ac.getAccountNo() == accNo) {
			System.out.println("current account balance :" + ac.getAccountBalance());
		} else {
			System.out.println("account does't exit");
		}

	}

	@Override
	public void depositMony() {
		System.out.println("enter your account");
		int accNo = sc.nextInt();
		if (ac.getAccountNo() == accNo) {
			System.out.println("enter amount you want to deposite");
			double add = sc.nextDouble();
			double updatedBalence = add + ac.getAccountBalance();
			ac.setAccountBalance(updatedBalence);
			System.out.println("Total account balance" + ac.getAccountBalance());
		} else {
			System.out.println("please deposit amount above 1000");
		}

	}

	@Override
	public void withdrowMony() {
		System.out.println("enter your account");
		int accNo = sc.nextInt();
		if (ac.getAccountNo() == accNo) {
			System.out.println("enter amount you want to Withdrow");
			double sub = sc.nextDouble();
			double updatedBalence = sub - ac.getAccountBalance();
			ac.setAccountBalance(updatedBalence);
			System.out.println("remaining amount" + ac.getAccountBalance());
		} else {
			System.out.println("Withdrow minimum 500");
		}

	}

	@Override
	public void upDateAccountDitails() {
		System.out.println("Enter your Account number");
		int accNo = sc.nextInt();
		if (ac.getAccountNo() == accNo) {
			boolean b = true;
			while (b) {

				System.out.println("1 :Update your Name");
				System.out.println("2 :Update your Contact number");
				System.out.println("3 :Update your mail id");
				System.out.println("4 exit ");
				System.out.println("Enter choise what you update from your account...");
				int choise = sc.nextInt();

				switch (choise) {
				case 1:
					System.out.println(" enter your new name ");
					String newName = sc.next();
					this.ac.setAccountName(newName);
					break;
				case 2:
					System.out.println("Enter your new Contact number");
					long newContact = sc.nextLong();
					this.ac.setContact(newContact);
					break;
				case 3:
					System.out.println("Enter your new mail id");
					String newMailId = sc.next();
					this.ac.setMail(newMailId);
					break;
				case 4:
					b = false;
					break;
				default:
					System.out.println("invalid choise plese enter valid choise...");

				}
			}

			System.out.println("Account Updated Sucessful...");
		} else {
			System.out.println("Account doesn't exist...");
		}

	}

}
