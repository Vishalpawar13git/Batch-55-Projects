package com.exponent.BankApplicationMiniProjectBassedOnOops.model;

public class Account {
	private long accountNo;
	private String accountName;
	private String aadharcard;
	private String panCard;
	private long contact;
	private String mail;
	private double accountBalance;

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String s) {
		this.accountName = s;
	}

	public String getAadharcard() {
		return aadharcard;
	}

	public void setAadharcard(String aadharcard) {
		this.aadharcard = aadharcard;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "Model accountNo=" + accountNo +"\n"+ " accountName=" + accountName + "\n"+" aadharcard=" + aadharcard
				
				+ "\n"+" panCard=" + panCard +"\n"+ " contact=" + contact +"\n"+ " mail=" + mail +"\n"+ " accountBalance="
				+ accountBalance +"";
	}

}
